from django.contrib import admin
from miniapp import models
# Register your models here.

admin.site.register(models.CategoryModel)
admin.site.register(models.PostModel)
admin.site.register(models.CommentModel)
