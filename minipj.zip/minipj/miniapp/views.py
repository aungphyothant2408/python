from django.shortcuts import render,redirect
from miniapp.models import * 
from django.db.models import Q
from django.core.paginator import Paginator
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required,permission_required
from django.conf import settings
from django.core.mail import send_mail
# Create your views here.
 
# search
def SearchBy(request):
    if request.method == "GET":
        search = request.GET.get('search')
        if search:
            posts = PostModel.objects.filter(
                Q(title__icontains = search) |
                Q(category__name__icontains = search)
            ).order_by('-created_at')
            context = {
                'posts':posts
            }
            return render(request,'index.html',context)
        else:
            posts = PostModel.objects.all().order_by('-created_at')
            context = {
                'posts':posts
            }
            return render(request,'index.html',context)
def Index(request):
    posts = PostModel.objects.all().order_by('-created_at')
    paginator = Paginator(posts, 2)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'posts' : page_obj
    }
    return render(request,"index.html",context)
@permission_required('miniapp.view_categorymodal',login_url='/login/')
def CategoryList(request):
    categories = CategoryModel.objects.all().order_by('-created_at')
    context = {
        'categories' : categories
    }
    return render(request,"category_list.html",context)
@permission_required('miniapp.view_categorymodal',login_url='/login/')
def CategoryCreate(request):
    if request.method == "POST":    
        category = CategoryModel.objects.create(
            name = request.POST['name'],
            description = request.POST['description'],
        )
        category.save()
        return redirect("/categories/list/")
def CategoryUpdate(request,pk):
    category = CategoryModel.objects.get(id = pk)
    if request.method == "POST":
     category.name = request.POST['name']
     category.description = request.POST['description']
     category.save()
     return redirect("/categories/list/")
    
def CategoryDelete(request,pk):
    category = CategoryModel.objects.get(id = pk)
    if request.method == "POST":
       category.delete()
       return redirect("/categories/list/")
def PostList(request):
    posts = PostModel.objects.all().order_by('-created_at')
    categories = CategoryModel.objects.all().order_by('-created_at')
    context = {
        'posts' : posts,
        'categories' : categories
    }
    return render(request,"post_list.html",context)
def PostCreate(request):
    if request.method == "POST":
        post = PostModel.objects.create(
            title = request.POST['title'],
            #  title = request.POST.get('title','sample post'),
            description = request.POST['description'],
            image = request.FILES.get('image'),
            category_id = request.POST['category'],
        )
        post.save()
        return redirect("/posts/list/")
def PostUpdate(request,pk):
    post = PostModel.objects.get(id = pk)
    if request.method =="POST":
        post.title = request.POST['title']
        post.description = request.POST['description']
        if request.FILES.get('image'):
            post.image.delete()
            post.image = request.FILES.get('image')
        post.category_id = request.POST.get('category')
        post.save()
        return redirect("/posts/list/")
def PostDelete(request,pk):
    post = PostModel.objects.get(id = pk)
    if request.method == "POST":
        if post.image:
            post.image.delete()
        post.delete()
        return redirect("/posts/list/")
def LoginViews(reuqest):
    if reuqest.method == "GET":
      return render(reuqest,"login.html")
    if reuqest.method =="POST":
        user = authenticate(
            username = reuqest.POST['username'],
            password = reuqest.POST['password']
        )
        # if user is not None
        if user:
            login(reuqest,user)
            messages.success(reuqest,"Login sucessfully")
            return redirect('/')
        else:
            messages.error(reuqest,"Invalid username or password")
            return redirect('/login/')
        
def LogoutViews(request):
    logout(request)
    return redirect('/login/')
def PostDetails(request,pk):
    post = PostModel.objects.get(id = pk)
    comments = CommentModel.objects.filter(post_id = post.id).order_by('-created_at')
    context = {
        'post':post,
        'comments' : comments
    }
    return render(request,"post_detail.html",context)
def CommentCreate(request,pk):
    author = User.objects.get(id = request.user.id)
    post = PostModel.objects.get(id = pk)
    if request.method == "POST":
       comment = CommentModel.objects.create(
           author = author,
           post = post,
           message = request.POST['message']
       )
       comment.save()
       messages.success(request,"Comment Successfully")
    #    return redirect
       return redirect(f'/posts/detail/{pk}/#comment-box')
    
def CommentUpdate(request,pk):
    comment = CommentModel.objects.get(id = pk)
    if request.method == "POST":
        comment.message = request.POST['message'],
    comment.save()
    messages.success(request,"comment updated successfully")
    return redirect(f'/posts/detail/{comment.post.id}/#comment-box')
def CommentDelete(request,pk):
    comment = CommentModel.objects.get(id = pk)
    if request.method == "POST":
        comment.delete()
        messages.success(request,"comment deleted successfully")
        return redirect(f'/posts/detail/{comment.post.id}/#comment-box')
def Register(request):
    if request.method == "GET":
        return render(request,"register.html")
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password_confirm = request.POST['password_confirm']
        if User.objects.filter(username = username):
            messages.error(request,"User already exists")
            return redirect('/register/')
        if User.objects.filter(email = email):
            messages.error(request,"email already exists")
            return redirect('/register/')
        if password == password_confirm:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
            )
            user.save()
            subject = 'New User Register'
            message = f'username is  {user.username}, Emain is {user.email}'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [user.email,]
            send_mail( subject,message,email_from,recipient_list)
            login(request,user)
            messages.success(request,"Register successfully")
            return redirect('/')
        else:
            messages.error(request,"Password does not match")
            return redirect('/register/')   