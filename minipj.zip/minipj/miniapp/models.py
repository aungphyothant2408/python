from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class CategoryModel(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
      return self.name
   
class PostModel(models.Model):
   title = models.CharField(max_length=200) 
   image = models.ImageField(upload_to="post_image",null=True)
   description = models.TextField()
   category = models.ForeignKey(CategoryModel,on_delete=models.CASCADE)
   # category = models.ForeignKey(CategoryModel,on_delete=models.CASCADE.null=True)
   # (.SET_NULL,null=True) and (.CASCADE) and (.PROTECT)
   created_at = models.DateTimeField(auto_now_add=True)
   updated_at = models.DateTimeField(auto_now=True)
   def __str__(self):
      return self.title
   
class CommentModel(models.Model):
   author = models.ForeignKey(User,on_delete=models.CASCADE)
   post = models.ForeignKey(PostModel,on_delete=models.CASCADE)
   message = models.TextField()
   created_at = models.DateTimeField(auto_now_add=True)
   updated_at = models.DateTimeField(auto_now=True)

