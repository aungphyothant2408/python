"""
URL configuration for minipj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from miniapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",views.Index),
    path("login/",views.LoginViews),
    path("search_by/",views.SearchBy),
    path("categories/list/",views.CategoryList),
    path("categories/create/",views.CategoryCreate),
    path("categories/update/<int:pk>/",views.CategoryUpdate),
    path("categories/delete/<int:pk>/",views.CategoryDelete),
    path("logout/",views.LogoutViews),
    path("register/",views.Register),
    
    path("posts/list/",views.PostList),
    path("posts/create/",views.PostCreate),
    path("posts/update/<int:pk>/",views.PostUpdate),
    path("posts/delete/<int:pk>/",views.PostDelete),
    path("posts/detail/<int:pk>/",views.PostDetails),
    # comment
    path("comments/create/<int:pk>/",views.CommentCreate),
    path("comments/update/<int:pk>/",views.CommentUpdate),
    path("comments/delete/<int:pk>/",views.CommentDelete),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)