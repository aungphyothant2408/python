

phoneMenu = document.getElementById('phoneMenu');
op = document.getElementById('op');
op.style.display = 'none';
phoneMenu.style.left='-100%';
function menuBar(){
    phoneMenu.style.left='1%';
    op.style.display = 'block';
}
function closemenu(){
    phoneMenu.style.left='-100%';
    op.style.display = 'none';
}
function viewall(){
    document.getElementById('box_container').classList.remove('preview');
    document.getElementById('box_container').classList.add('viewall');
}
function preview(){
    document.getElementById('box_container').classList.remove('viewall');
    document.getElementById('box_container').classList.add('preview');
}
