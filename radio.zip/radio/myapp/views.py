from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required,permission_required
from datetime import datetime
from django.db.models import Q
from django.core.paginator import Paginator
from datetime import date,timedelta
from django.core.paginator import Paginator

# Create your views here.

def about_search(request):
    if request.method == 'GET':
        search = request.GET.get('search')
        if search:
            about = AboutModel.objects.filter(
                Q(name__icontains=search) |
                Q(position__icontains=search) |
                Q(age__icontains=search)
                ).order_by('-updated_at')
            context = {
                'abouts':about
                }
            return render(request, 'about.html',context)
        else:
            about =AboutModel.objects.all().order_by('-created_at')
            context = {
                'about':about
            }
            return render(request,'about.html', context)
        
def event_search(request):
    if request.method == 'GET':
        search = request.GET.get('search')
        if search:
            event = EventModel.objects.filter(
                Q(singer__icontains=search) |
                Q(description__icontains=search)
                ).order_by('-updated_at')
            context = {
                'events':event
                }
            return render(request, 'event.html',context)
        else:
            event =EventModel.objects.all().order_by('-created_at')
            context = {
                'event':event
            }
            return render(request,'event.html', context)
        
def table_booking_search(request):
    if request.method == 'GET':
        search = request.GET.get('search')
        if search:
            booking = TableBookingModel.objects.filter(
                Q(bookingday__icontains=search) |
                Q(singer__singer__icontains=search)
                ).order_by('-updated_at')
            context = {
                'bookings':booking
                }
            return render(request, 'table_booking.html',context)
        else:
            booking =TableBookingModel.objects.all().order_by('-created_at')
            context = {
                'booking':booking
            }
            return render(request,'table_booking.html', context)


def index(request):
    return render(request,'index.html')

def about(request):
    about = AboutModel.objects.all().order_by('-created_at')
    context = {'abouts':about}
    return render(request,'about.html',context)

def about_detail(request,pk):
    about = AboutModel.objects.get(id=pk)
    if request.method == 'GET':
        context = {'about':about}
        return render(request,'about_detail.html',context)
    
def about_create(request):
    if request.method == 'POST':
        about = AboutModel.objects.create(
            name = request.POST.get('name'),
            image = request.FILES.get('image'),
            position = request.POST.get('position'),
            age = request.POST.get('age'),
            description = request.POST.get('description')
        )
        about.save()
        messages.success(request,'Your about has been added successfully.')
        return redirect(f'/about/#heading')

def about_update(request,pk):
    about = AboutModel.objects.get(id=pk)
    if request.method == 'POST':
        about.name = request.POST.get('name')
        about.position = request.POST.get('position')
        about.age = request.POST.get('age')
        about.description = request.POST.get('description')
        if request.FILES.get('image'):
            about.image.delete()
            about.image = request.FILES.get('image')
        about.save()
        messages.success(request,'Your about has been updated successfully.')
        return redirect(f'/about/detail/{pk}/')

def about_delete(request,pk):
    about = AboutModel.objects.get(id=pk)
    if request.method == 'POST':
        if about.image:
            about.image.delete()
        about.delete()
        messages.success(request,'Your about has been deleted successfully.')
        return redirect(f'/about/#heading')
        
def event(request):
    today_date= date.today().strftime("%Y-%m-%d")
    tomorrow_date = (date.today()+ timedelta(days=1)).strftime("%Y-%m-%d")
    event = EventModel.objects.all().order_by('-created_at')
    context = {
        'events':event,
        'today_date':today_date,
        'tomorrow_date':tomorrow_date
        }
    return render(request,'event.html',context)

def event_detail(request,pk):
    event = EventModel.objects.get(id=pk)
    today_date= date.today().strftime("%Y-%m-%d")
    tomorrow_date = (date.today()+ timedelta(days=1)).strftime("%Y-%m-%d")
    if request.method == 'GET':
        context = {
            'event':event,
            'today_date':today_date,
            'tomorrow_date':tomorrow_date
        }
        return render(request,'event_detail.html',context)

def event_create(request):
    if request.method == 'POST':
        event = EventModel.objects.create(
            singer = request.POST.get('singer'),
            image = request.FILES.get('image'),
            eventstart = request.POST.get('startTime'),
            eventend= request.POST.get('endTime'),
            description = request.POST.get('description')
        )
        event.save()
        messages.success(request,'Your event has been added successfully.')
        return redirect(f'/event/#heading')

def event_update(request,pk):
    event = EventModel.objects.get(id=pk)
    if request.method == 'POST':
        event.singer = request.POST.get('singer')
        event.eventstart = request.POST.get('startTime')
        event.eventend = request.POST.get('endTime')
        event.description = request.POST.get('description')
        if request.FILES.get('image'):
            event.image.delete()
            event.image = request.FILES.get('image')
        event.save()
        messages.success(request,'Your event has been updated successfully.')
        return redirect(f'/event/detail/{pk}/')

def event_delete(request,pk):
    event = EventModel.objects.get(id=pk)
    if request.method == 'POST':
        if event.image:
            event.image.delete()
        event.delete()
        messages.success(request,'Your event has been deleted successfully.')
        return redirect(f'/event/#heading')

def food_drink(request):
    foods = FoodModel.objects.all().order_by('-created_at')
    food_paginator = Paginator(foods,6)
    food_number = request.GET.get('food')
    food_obj = food_paginator.get_page(food_number)
    drinks = DrinkModel.objects.all().order_by('-created_at')
    drink_paginator = Paginator(drinks,6)
    drink_number = request.GET.get('drink')
    drink_obj = drink_paginator.get_page(drink_number)
    context = {
        'foods':food_obj,
        'drinks':drink_obj,
    }
    return render(request,'food_drink.html',context)

def drink_create(request):
    if request.method == 'POST':
        drink = DrinkModel.objects.create(
            drinkname = request.POST.get('name'),
            drinkprice = request.POST.get('price'),
            drinkdescription = request.POST.get('description'),
            drinkimage = request.FILES.get('image'),
        )
        drink.save()
        messages.success(request,'Your drink has been added successfully.')
        return redirect(f'/food_drink/#drinkheading')

def drink_delete(request,pk):
    drink = DrinkModel.objects.get(id=pk)
    if request.method == "GET":
        if drink.drinkimage:
            drink.drinkimage.delete()
        drink.delete()
        messages.success(request,'Your drink has been deleted successfully.')
        return redirect(f'/food_drink/#drinkheading')

def food_create(request):
    if request.method == 'POST':
        food = FoodModel.objects.create(
            foodname = request.POST.get('name'),
            foodprice = request.POST.get('price'),
            fooddescription = request.POST.get('description'),
            foodimage = request.FILES.get('image'),
        )
        food.save()
        messages.success(request,'Your food has been added successfully.')
        return redirect(f'/food_drink/#foodheading')

def food_delete(request,pk):
    food = FoodModel.objects.get(id=pk)
    if request.method == "GET":
        if food.foodimage:
            food.foodimage.delete()
        food.delete()
        messages.success(request,'Your food has been deleted successfully.')
        return redirect(f'/food_drink/#foodheading')
  
def table_booking(request):
    event = EventModel.objects.all().order_by('-created_at')
    bookings = TableBookingModel.objects.all().order_by('-created_at')
    context = {
        'events':event,
        'bookings':bookings
        }
    return render(request,'table_booking.html',context)

def table_booking_create(request):
    if request.method == 'POST':
        booking = TableBookingModel.objects.create(
            bookingday = request.POST.get('day'),
            singer_id = request.POST.get('singer'),
            description = request.POST.get('description'),
            tableon = request.POST.get('starton'),
        )
        booking.save()
        messages.success(request,'Your table has been booked successfully.')
        return redirect(f'/table_booking/#heading')

def table_booking_update(request,pk):
    booking = TableBookingModel.objects.get(id=pk)
    if request.method == 'POST':
        booking.bookingday = request.POST.get('day')
        booking.save()
        messages.success(request,'Your table has been updated successfully.')
        return redirect(f'/table_detail/{pk}/')
    
def table_booking_delete(request,pk):
    booking = TableBookingModel.objects.get(id=pk)
    if request.method == 'POST':
        booking.delete()
        messages.success(request,'Your table has been deleted successfully.')
        return redirect(f'/table_booking/#heading')

def table_detail(request,pk):
    booking = TableBookingModel.objects.get(id=pk)
    tables = DetailBookingModel.objects.filter(table_id = booking.id)
    foods = FoodModel.objects.all()
    drinks = DrinkModel.objects.all()
    context = {
        'booking':booking,
        'tables':tables,
        'foods':foods,
        'drinks':drinks
        }
    return render(request,'table_detail.html',context)

def table_ticket_create(request,pk):
    booking = TableBookingModel.objects.get(id=pk)
    if request.method == 'POST':
        tables = DetailBookingModel.objects.create(
            table = booking,
            tableno = request.POST.get('tableno'),
            foodpackage_id = request.POST.get('food'),
            drinkpackage_id = request.POST.get('drink'),
            price = request.POST.get('price'),
        )
        tables.save()
        messages.success(request,'Your table has been booked successfully.')
        return redirect(f'/table_detail/{pk}/#heading')

def bookingnow(request,pk):
    tables = DetailBookingModel.objects.get(id=pk)
    booking = TableBookingModel.objects.get(id=tables.table.id)
    events = EventModel.objects.get(id=booking.singer.id)
    context = {
        'tables':tables,
        'booking':booking,
        'events':events,
    }
    return render(request,'booking.html',context)

def booking_active(request,pk):
    table = DetailBookingModel.objects.get(id=pk)
    if request.method == 'GET':
        table.active=True
        table.save()
        return redirect(f'/table_detail/{pk}/#heading')
    
def booking_Deactive(request,pk):
    table = DetailBookingModel.objects.get(id=pk)
    if request.method == 'GET':
        table.active=False
        table.save()
        return redirect('/table_booking/')
    
def bookingnow_create(request,pk):
    tables= DetailBookingModel.objects.get(id=pk)
    if request.method == 'POST':
        bookingnow = BookingModel.objects.create(
            bookingname = request.POST.get('name'),
            date = request.POST.get('day'),
            tablebooking = tables,
            address = request.POST.get('address'),
            phone = request.POST.get('phone'),
            people = request.POST.get('people'),
        )
        bookingnow.save()
        return redirect(f'/booking_end/{pk}/')
    
def booking_end(request,pk):
    table = DetailBookingModel.objects.get(id=pk)
    if request.method == 'GET':
        context = {
            'table':table
        }
        return render(request,'booking_end.html',context)

def booking_list(request):
    bookingnow = BookingModel.objects.all().order_by('-created_at')
    context = {'bookingnow':bookingnow}
    return render(request,'booking_list.html',context)

def booking_list_delete(request,pk):
    bookingnow = BookingModel.objects.get(id=pk)
    if request.method == 'GET':
        bookingnow.delete()
        messages.success(request,'Your booking has been deleted successfully.')
        return redirect(f'/booking_list/#heading')

def login_view(request):
    if request.method == 'GET':
        return render(request,'login.html')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            messages.success(request,'Login successfully.')
            return redirect('/')
        else:
            messages.error(request,'Invalid username or password.')
            return redirect('/login/')
        
def logout_view(request):
    if request.method == 'GET':
        logout(request)
        return redirect('/')
    
def contact(request):
    if request.method == 'GET':
        return render(request,'contact.html')
    
def contact_create(request):
    if request.method == 'POST':
        contact = ContactModel.objects.create(
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            phone = request.POST.get('phone'),
            message = request.POST.get('message')
        )
        contact.save()
        messages.success(request,'Your message has been sent successfully.')
        return redirect('/contact/')
    
def contact_list(request):
    contact = ContactModel.objects.all().order_by('-created_at')
    context = {'contact':contact}
    return render(request,'contact_list.html',context)

def contact_delete(request,pk):
    contact = ContactModel.objects.get(id=pk)
    if request.method == 'GET':
        contact.delete()
        messages.success(request,'Your message has been deleted successfully.')
        return redirect('/contact_list/#heading')