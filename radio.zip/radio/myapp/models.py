from django.db import models
from datetime import datetime
from django.contrib.auth.models import User
# Create your models here.


#about employee 
class AboutModel(models.Model):
    name = models.CharField(max_length=255)
    position = models.TextField()
    image = models.FileField(upload_to='about_image')
    description = models.TextField()
    age = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)    
    def __str__(self):
      return self.name
  
class FoodModel(models.Model):
    foodname  = models.CharField(max_length=255)
    foodprice = models.TextField()
    foodimage = models.FileField(upload_to='food_image')
    fooddescription = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.foodname
    
class DrinkModel(models.Model):
    drinkname  = models.CharField(max_length=255)
    drinkprice = models.TextField()
    drinkimage = models.FileField(upload_to='drink_image')
    drinkdescription = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.drinkname
    
class EventModel(models.Model):
    singer = models.CharField(max_length=255)
    image = models.FileField(upload_to='event_image')
    eventstart = models.DateField()
    eventend = models.DateField()
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.singer
    
class TableBookingModel(models.Model):
    bookingday = models.DateField()
    singer = models.ForeignKey(EventModel,on_delete=models.SET_NULL, null=True)
    description = models.TextField()
    tableon = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __int__(self):
        return self.bookingday
    
class DetailBookingModel(models.Model):
    tableno = models.CharField(max_length=255)
    price = models.IntegerField()
    table = models.ForeignKey(TableBookingModel,on_delete=models.CASCADE)
    foodpackage = models.ForeignKey(FoodModel,on_delete=models.SET_NULL, null=True)
    drinkpackage = models.ForeignKey(DrinkModel,on_delete=models.SET_NULL, null=True)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.tableno

class BookingModel(models.Model):
    bookingname = models.CharField(max_length=255,null=True)
    date = models.TextField(max_length=255,null=True)
    tablebooking = models.ForeignKey(DetailBookingModel,on_delete=models.CASCADE)
    address = models.TextField()
    phone = models.IntegerField(null=True)
    people = models.IntegerField()
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.bookingname
    
    
class ContactModel(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.IntegerField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.name