from django.contrib import admin
from myapp import models
# Register your models here.

admin.site.register(models.AboutModel)
admin.site.register(models.BookingModel)
admin.site.register(models.DetailBookingModel)
admin.site.register(models.EventModel)
admin.site.register(models.DrinkModel)
admin.site.register(models.FoodModel)
admin.site.register(models.TableBookingModel)
admin.site.register(models.ContactModel)