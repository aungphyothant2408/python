"""
URL configuration for radio project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views
from django.conf.urls.static import static
from django.conf import settings
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/',views.login_view),
    path('logout/',views.logout_view),
    
    path('',views.index),
    
    path('about/',views.about),
    path('about/create/',views.about_create),
    path('about/detail/<int:pk>/',views.about_detail),
    path('about/update/<int:pk>/',views.about_update),
    path('about/delete/<int:pk>/',views.about_delete),
    path('search/about/',views.about_search),
    
    path('event/',views.event),
    path('event/detail/<int:pk>/',views.event_detail),
    path('event/create/',views.event_create),
    path('event/update/<int:pk>/',views.event_update),
    path('event/delete/<int:pk>/',views.event_delete),
    path('search/event/',views.event_search),
    
    path('food_drink/',views.food_drink),
    path('food_drink/drink/create/',views.drink_create),
    path('food_drink/drink/delete/<int:pk>/',views.drink_delete),
    path('food_drink/food/create/',views.food_create),
    path('food_drink/food/delete/<int:pk>/',views.food_delete),
    
    path('table_booking/',views.table_booking),
    path('table_booking/create/',views.table_booking_create),
    path('table_booking/update/<int:pk>/',views.table_booking_update),
    path('table_booking/delete/<int:pk>/',views.table_booking_delete),
    path('search/table_booking/',views.table_booking_search),
    
    path('table_detail/<int:pk>/',views.table_detail),
    path('ticket/create/<int:pk>/',views.table_ticket_create),
    
    path('bookingnow/<int:pk>/',views.bookingnow),
    path('bookingnow/create/<int:pk>/',views.bookingnow_create),
    path('booking_list/delete/<int:pk>/',views.booking_list_delete),
    path('booking/active/<int:pk>/',views.booking_active),
    path('booking/deactive/<int:pk>/',views.booking_Deactive),
    
    path('booking_end/<int:pk>/',views.booking_end),
    path('booking_list/',views.booking_list),
    
    path('contact/',views.contact),
    path('contact/create/',views.contact_create),
    path('contact/delete/<int:pk>/',views.contact_delete),
    path('contact_list/',views.contact_list),
    
]+static(settings.MEDIA_URL ,document_root=settings.MEDIA_ROOT)
